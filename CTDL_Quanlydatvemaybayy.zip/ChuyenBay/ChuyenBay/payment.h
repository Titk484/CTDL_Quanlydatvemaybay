#pragma once
#include<iostream>
#include<string.h>
using namespace std;

int payment;

int lpayment(char origin[30], char destination[30]) {

	if ((strcmp(origin, "HAIPHONG") == 0) || (strcmp(origin, "HUE") == 0) && (strcmp(destination, "HAIPHONG") == 0) || (strcmp(destination, "HUE") == 0))
		return payment = 300000;
	else if ((strcmp(origin, "HAIPHONG") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "HAIPHONG") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 100000;
	else if ((strcmp(origin, "HAIPHONG") == 0) || (strcmp(origin, "SONLA") == 0) && (strcmp(destination, "HAIPHONG") == 0) || (strcmp(destination, "SONLA") == 0))
		return payment = 200000;
	else if ((strcmp(origin, "HAIPHONG") == 0) || (strcmp(origin, "NGHEAN") == 0) && (strcmp(destination, "HAIPHONG") == 0) || (strcmp(destination, "NGHEAN") == 0))
		return payment = 200000;
	else if ((strcmp(origin, "HUE") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "HUE") == 0) || (strcmp(destination, "HANOI") == 0))
		payment = 1000000;
	else if ((strcmp(origin, "HUE") == 0) || (strcmp(origin, "SONLA") == 0) && (strcmp(destination, "HUE") == 0) || (strcmp(destination, "SONLA") == 0))
		return payment = 2000000;
	else if ((strcmp(origin, "HUE") == 0) || (strcmp(origin, "NGHEAN") == 0) && (strcmp(destination, "HUE") == 0) || (strcmp(destination, "NGHEAN") == 0))
		return payment = 800000;
	else if ((strcmp(origin, "HANOI") == 0) || (strcmp(origin, "SONLA") == 0) && (strcmp(destination, "HANOI") == 0) || (strcmp(destination, "SONLA") == 0))
		return payment = 100000;
	else if ((strcmp(origin, "HANOI") == 0) || (strcmp(origin, "NGHEAN") == 0) && (strcmp(destination, "HANOI") == 0) || (strcmp(destination, "NGHEAN") == 0))
		return payment = 500000;
}

int ipayment(char origin[30], char destination[30]) {

	if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "CANTHO") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "CANTHO") == 0))
		return payment = 300000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "CAMAU") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "CAMAU") == 0))
		return payment = 800000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "VUNGTAU") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "VUNGTAU") == 0))
		return payment = 100000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "NHATRANG") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "NHATRANG") == 0))
		return payment = 1000000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "DALAT") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "DALAT") == 0))
		return payment = 900000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "QUYNHON") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "QUYNHON") == 0))
		return payment = 1050000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "RACHGIA") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "RACHGIA") == 0))
		return payment = 100000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "PHUQUOC") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "PHUQUOC") == 0))
		return payment = 1500000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 2000000;
	else if ((strcmp(origin, "TPHCM") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "TPHCM") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 2500000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "CAMAU") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "CAMAU") == 0))
		return payment = 500000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "VUNGTAU") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "VUNGTAU") == 0))
		return payment = 500000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "NHATRANG") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "NHATRANG") == 0))
		return payment = 900000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "DALAT") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "DALAT") == 0))
		return payment = 800000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "QUYNHON") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "QUYNHON") == 0))
		return payment = 1200000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "RACHGIA") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "RACHGIA") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "PHUQUOC") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "PHUQUOC") == 0))
		return payment = 500000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 200000;
	else if ((strcmp(origin, "CANTHO") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "CANTHO") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 1250000;
	else if ((strcmp(origin, "CAMAU") == 0) || (strcmp(origin, "VUNGTAU") == 0) && (strcmp(destination, "CAMAU") == 0) || (strcmp(destination, "VUNGTAU") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "CAMAU") == 0) || (strcmp(origin, "NHATRANG") == 0) && (strcmp(destination, "CAMAU") == 0) || (strcmp(destination, "NHATRANG") == 0))
		return payment = 1500000;
	else if ((strcmp(origin, "CAMAU") == 0) || (strcmp(origin, "DALAT") == 0) && (strcmp(destination, "CAMAU") == 0) || (strcmp(destination, "DALAT") == 0))
		return payment = 1000000;
	else if ((strcmp(origin, "CAMAU") == 0) || (strcmp(origin, "QUYNHON") == 0) && (strcmp(destination, "CAMAU") == 0) || (strcmp(destination, "QUYNHON") == 0))
		return payment = 3000000;
	else if ((strcmp(origin, "CAMAU") == 0) || (strcmp(origin, "RACHGIA") == 0) && (strcmp(destination, "CAMAU") == 0) || (strcmp(destination, "RACHGIA") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "CAMAU") == 0) || (strcmp(origin, "PHUQUOC") == 0) && (strcmp(destination, "CAMAU") == 0) || (strcmp(destination, "PHUQUOC") == 0))
		return payment = 400000;
	else if ((strcmp(origin, "CAMAU") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "CAMAU") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "CAMAU") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "CAMAU") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 5000000;
	else if ((strcmp(origin, "VUNGTAU") == 0) || (strcmp(origin, "NHATRANG") == 0) && (strcmp(destination, "VUNGTAU") == 0) || (strcmp(destination, "NHATRANG") == 0))
		return payment = 300000;
	else if ((strcmp(origin, "VUNGTAU") == 0) || (strcmp(origin, "DALAT") == 0) && (strcmp(destination, "VUNGTAU") == 0) || (strcmp(destination, "DALAT") == 0))
		return payment = 600000;
	else if ((strcmp(origin, "VUNGTAU") == 0) || (strcmp(origin, "QUYNHON") == 0) && (strcmp(destination, "VUNGTAU") == 0) || (strcmp(destination, "QUYNHON") == 0))
		return payment = 500000;
	else if ((strcmp(origin, "VUNGTAU") == 0) || (strcmp(origin, "RACHGIA") == 0) && (strcmp(destination, "VUNGTAU") == 0) || (strcmp(destination, "RACHGIA") == 0))
		return payment = 400000;
	else if ((strcmp(origin, "VUNGTAU") == 0) || (strcmp(origin, "PHUQUOC") == 0) && (strcmp(destination, "VUNGTAU") == 0) || (strcmp(destination, "PHUQUOC") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "VUNGTAU") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "VUNGTAU") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 1000000;
	else if ((strcmp(origin, "VUNGTAU") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "VUNGTAU") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 1050000;
	else if ((strcmp(origin, "NHATRANG") == 0) || (strcmp(origin, "DALAT") == 0) && (strcmp(destination, "NHATRANG") == 0) || (strcmp(destination, "DALAT") == 0))
		return payment = 500000;
	else if ((strcmp(origin, "NHATRANG") == 0) || (strcmp(origin, "QUYNHON") == 0) && (strcmp(destination, "NHATRANG") == 0) || (strcmp(destination, "QUYNHON") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "NHATRANG") == 0) || (strcmp(origin, "RACHGIA") == 0) && (strcmp(destination, "NHATRANG") == 0) || (strcmp(destination, "RACHGIA") == 0))
		return payment = 800000;
	else if ((strcmp(origin, "NHATRANG") == 0) || (strcmp(origin, "PHUQUOC") == 0) && (strcmp(destination, "NHATRANG") == 0) || (strcmp(destination, "PHUQUOC") == 0))
		return payment = 800000;
	else if ((strcmp(origin, "NHATRANG") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "NHATRANG") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "NHATRANG") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "NHATRANG") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 1000000;
	else if ((strcmp(origin, "DALAT") == 0) || (strcmp(origin, "QUYNHON") == 0) && (strcmp(destination, "DALAT") == 0) || (strcmp(destination, "QUYNHON") == 0))
		return payment = 1000000;
	else if ((strcmp(origin, "DALAT") == 0) || (strcmp(origin, "RACHGIA") == 0) && (strcmp(destination, "DALAT") == 0) || (strcmp(destination, "RACHGIA") == 0))
		return payment = 300000;
	else if ((strcmp(origin, "DALAT") == 0) || (strcmp(origin, "PHUQUOC") == 0) && (strcmp(destination, "DALAT") == 0) || (strcmp(destination, "PHUQUOC") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "DALAT") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "DALAT") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 900000;
	else if ((strcmp(origin, "DALAT") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "DALAT") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 1500000;
	else if ((strcmp(origin, "QUYNHON") == 0) || (strcmp(origin, "RACHGIA") == 0) && (strcmp(destination, "QUYNHON") == 0) || (strcmp(destination, "RACHGIA") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "QUYNHON") == 0) || (strcmp(origin, "PHUQUOC") == 0) && (strcmp(destination, "QUYNHON") == 0) || (strcmp(destination, "PHUQUOC") == 0))
		return payment = 750000;
	else if ((strcmp(origin, "QUYNHON") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "QUYNHON") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 800000;
	else if ((strcmp(origin, "QUYNHON") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "QUYNHON") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 500000;
	else if ((strcmp(origin, "RACHGIA") == 0) || (strcmp(origin, "PHUQUOC") == 0) && (strcmp(destination, "RACHGIA") == 0) || (strcmp(destination, "PHUQUOC") == 0))
		return payment = 500000;
	else if ((strcmp(origin, "RACHGIA") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "RACHGIA") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 300000;
	else if ((strcmp(origin, "RACHGIA") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "RACHGIA") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 1000000;
	else if ((strcmp(origin, "PHUQUOC") == 0) || (strcmp(origin, "VINH") == 0) && (strcmp(destination, "PHUQUOC") == 0) || (strcmp(destination, "VINH") == 0))
		return payment = 700000;
	else if ((strcmp(origin, "PHUQUOC") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "PHUQUOC") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 2000000;
	else if ((strcmp(origin, "VINH") == 0) || (strcmp(origin, "HANOI") == 0) && (strcmp(destination, "VINH") == 0) || (strcmp(destination, "HANOI") == 0))
		return payment = 700000;
}